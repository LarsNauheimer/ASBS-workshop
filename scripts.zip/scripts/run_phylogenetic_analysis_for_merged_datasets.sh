#!/bin/bash
############


set +e
set -u
set -o pipefail


GAP_workshop_3_DIR=/vagrant/GAP_workshop_3/
THREADS=1
SIF_DIR=/home/vagrant/

while getopts 'g:t:s:' OPTION; do
  case "$OPTION" in

    
    g)
      GAP_workshop_3_DIR=$OPTARG
     ;;

    t)
      THREADS=$OPTARG
     ;;

    s)
      SIF_DIR=$OPTARG
     ;;


    ?)
      echo " Options:
		-g	<path>	Set path to GAP_workshop_3 folder. e.g. /home/username/GAP_workshops/GAP_workshop_3/
		
		-s	<file> 	Set path to Singularity file (hybpiper-yang-and-smith- rbgv_latest.sif) to run Astral. E.g /home/user/
		
		-t 	<number> Set number of threads used.
        " >&2
        
      exit 1
      ;;
  esac
done
shift "$(($OPTIND -1))"



for i in 1 2 
do
	if [ $i == 1 ]; then 
		NAME=contigs_phased_merged
		SEQ_LIST_FOLDER=$GAP_workshop_3_DIR/hybphaser_output/03_sequence_lists_phased_merged/loci_contigs
	else 
		NAME=consensus_phased_merged
		SEQ_LIST_FOLDER=$GAP_workshop_3_DIR/hybphaser_output/03_sequence_lists_phased_merged/loci_consensus
	fi

	OUTPUT_FOLDER=$GAP_workshop_3_DIR/hybphaser_output/04_phylogenetics


	#########################################

	ALIGN_FOLDER=$OUTPUT_FOLDER/$NAME/alignments/
	TRIM_FOLDER=$OUTPUT_FOLDER/$NAME/alignments_trimmed/
	mkdir -p $ALIGN_FOLDER	

	cd $SEQ_LIST_FOLDER 
	for i in *.*
	do
	mafft --thread $THREADS $i > $ALIGN_FOLDER/$i 
	done

	TREE_FOLDER=$OUTPUT_FOLDER/$NAME/trees
	mkdir -p $TREE_FOLDER
	cd $TREE_FOLDER

	# infer the locus trees
	iqtree2 -S $ALIGN_FOLDER --prefix "$TREE_FOLDER/loci_$NAME" -nt $THREADS --undo

	# compute ASTRAL tree
	singularity exec --bind $PWD $SIF_DIR/hybpiper-yang-and-smith-rbgv_latest.sif java -jar /Astral/astral.5.7.7.jar -i "$TREE_FOLDER/loci_$NAME.treefile" -o "$TREE_FOLDER/loci_$NAME.astral.tre"

	# infer a concatenation -based species tree with 1000 ultrafastbootstrap and an edge-linked partition model
	iqtree2 -p $ALIGN_FOLDER --prefix "$TREE_FOLDER/concat_$NAME" -bb 1000 -nt $THREADS --undo

	# compute concordance factors
	iqtree2 -t "$TREE_FOLDER/concat_$NAME.treefile" --gcf "$TREE_FOLDER/loci_$NAME.treefile" -p $ALIGN_FOLDER --scf 1000 --prefix "$TREE_FOLDER/concord_$NAME" -nt $THREADS --undo

done
